﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Late_Fee_Calculator
{
    public partial class frmLateFilms : Form
    {
        public frmLateFilms()
        {
            InitializeComponent();
        }
        private List<string> lateMovies = new List<string>();
        public static int NumCount { get; private set; }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //add the film name from the text box to the sorted list
            lateMovies.Add(txtMovieName.Text);
            //get the count of items in the SortedList
            NumCount = lateMovies.Count;
            // Display success message
            MessageBox.Show("Movie Added Successfully");
            //clear text box
            txtMovieName.Text = "";           
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            //DialogResult property of the form to OK
            this.DialogResult = DialogResult.OK;
        }

    }
}

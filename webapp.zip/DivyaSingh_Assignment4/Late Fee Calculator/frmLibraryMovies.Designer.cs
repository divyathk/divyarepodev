﻿namespace Late_Fee_Calculator
{
    partial class frmLibraryMovies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLibraryMovies));
            this.lblDueDate = new System.Windows.Forms.Label();
            this.txtDueDate = new System.Windows.Forms.TextBox();
            this.lblCurrentDate = new System.Windows.Forms.Label();
            this.txtCurrentDate = new System.Windows.Forms.TextBox();
            this.lblNumOfDaysLate = new System.Windows.Forms.Label();
            this.txtNumOfDaysLate = new System.Windows.Forms.TextBox();
            this.lblLateFee = new System.Windows.Forms.Label();
            this.txtLateFee = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.lblDateFormat = new System.Windows.Forms.Label();
            this.lblCustomerType = new System.Windows.Forms.Label();
            this.txtCustomerType = new System.Windows.Forms.TextBox();
            this.lblNoOfMovies = new System.Windows.Forms.Label();
            this.txtNoOfMovies = new System.Windows.Forms.TextBox();
            this.txtTotalMovieCount = new System.Windows.Forms.TextBox();
            this.lblTotalMovieCount = new System.Windows.Forms.Label();
            this.txtTotalLateFee = new System.Windows.Forms.TextBox();
            this.lblTotalLateFee = new System.Windows.Forms.Label();
            this.btnCount = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblDueDate
            // 
            this.lblDueDate.AutoSize = true;
            this.lblDueDate.Font = new System.Drawing.Font("Yu Gothic UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDueDate.Location = new System.Drawing.Point(71, 42);
            this.lblDueDate.Name = "lblDueDate";
            this.lblDueDate.Size = new System.Drawing.Size(86, 25);
            this.lblDueDate.TabIndex = 0;
            this.lblDueDate.Text = "Due Date";
            // 
            // txtDueDate
            // 
            this.txtDueDate.Location = new System.Drawing.Point(308, 42);
            this.txtDueDate.Name = "txtDueDate";
            this.txtDueDate.Size = new System.Drawing.Size(151, 29);
            this.txtDueDate.TabIndex = 1;
            // 
            // lblCurrentDate
            // 
            this.lblCurrentDate.AutoSize = true;
            this.lblCurrentDate.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.lblCurrentDate.Location = new System.Drawing.Point(71, 260);
            this.lblCurrentDate.Name = "lblCurrentDate";
            this.lblCurrentDate.Size = new System.Drawing.Size(112, 25);
            this.lblCurrentDate.TabIndex = 8;
            this.lblCurrentDate.Text = "Current Date";
            // 
            // txtCurrentDate
            // 
            this.txtCurrentDate.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtCurrentDate.Location = new System.Drawing.Point(308, 260);
            this.txtCurrentDate.Name = "txtCurrentDate";
            this.txtCurrentDate.ReadOnly = true;
            this.txtCurrentDate.Size = new System.Drawing.Size(151, 29);
            this.txtCurrentDate.TabIndex = 9;
            this.txtCurrentDate.TabStop = false;
            // 
            // lblNumOfDaysLate
            // 
            this.lblNumOfDaysLate.AutoSize = true;
            this.lblNumOfDaysLate.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.lblNumOfDaysLate.Location = new System.Drawing.Point(68, 335);
            this.lblNumOfDaysLate.Name = "lblNumOfDaysLate";
            this.lblNumOfDaysLate.Size = new System.Drawing.Size(180, 25);
            this.lblNumOfDaysLate.TabIndex = 10;
            this.lblNumOfDaysLate.Text = "Number of Days Late";
            // 
            // txtNumOfDaysLate
            // 
            this.txtNumOfDaysLate.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNumOfDaysLate.Location = new System.Drawing.Point(308, 331);
            this.txtNumOfDaysLate.Name = "txtNumOfDaysLate";
            this.txtNumOfDaysLate.ReadOnly = true;
            this.txtNumOfDaysLate.Size = new System.Drawing.Size(151, 29);
            this.txtNumOfDaysLate.TabIndex = 11;
            this.txtNumOfDaysLate.TabStop = false;
            // 
            // lblLateFee
            // 
            this.lblLateFee.AutoSize = true;
            this.lblLateFee.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.lblLateFee.Location = new System.Drawing.Point(71, 411);
            this.lblLateFee.Name = "lblLateFee";
            this.lblLateFee.Size = new System.Drawing.Size(75, 25);
            this.lblLateFee.TabIndex = 12;
            this.lblLateFee.Text = "Late Fee";
            // 
            // txtLateFee
            // 
            this.txtLateFee.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtLateFee.Location = new System.Drawing.Point(308, 411);
            this.txtLateFee.Name = "txtLateFee";
            this.txtLateFee.ReadOnly = true;
            this.txtLateFee.Size = new System.Drawing.Size(151, 29);
            this.txtLateFee.TabIndex = 13;
            this.txtLateFee.TabStop = false;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnCalculate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCalculate.Location = new System.Drawing.Point(69, 494);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(114, 50);
            this.btnCalculate.TabIndex = 14;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.OnCalculateButtonPressed);
            // 
            // btnReturn
            // 
            this.btnReturn.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnReturn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnReturn.Location = new System.Drawing.Point(308, 494);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(135, 50);
            this.btnReturn.TabIndex = 15;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.OnReturnButtonPressed);
            // 
            // lblDateFormat
            // 
            this.lblDateFormat.AutoSize = true;
            this.lblDateFormat.Location = new System.Drawing.Point(304, 74);
            this.lblDateFormat.Name = "lblDateFormat";
            this.lblDateFormat.Size = new System.Drawing.Size(190, 21);
            this.lblDateFormat.TabIndex = 2;
            this.lblDateFormat.Text = "Date format: dd-mm-yyyy";
            // 
            // lblCustomerType
            // 
            this.lblCustomerType.AutoSize = true;
            this.lblCustomerType.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.lblCustomerType.Location = new System.Drawing.Point(68, 115);
            this.lblCustomerType.Name = "lblCustomerType";
            this.lblCustomerType.Size = new System.Drawing.Size(130, 25);
            this.lblCustomerType.TabIndex = 3;
            this.lblCustomerType.Text = "Customer Type";
            // 
            // txtCustomerType
            // 
            this.txtCustomerType.Location = new System.Drawing.Point(308, 124);
            this.txtCustomerType.Name = "txtCustomerType";
            this.txtCustomerType.Size = new System.Drawing.Size(151, 29);
            this.txtCustomerType.TabIndex = 4;
            // 
            // lblNoOfMovies
            // 
            this.lblNoOfMovies.AutoSize = true;
            this.lblNoOfMovies.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.lblNoOfMovies.Location = new System.Drawing.Point(68, 189);
            this.lblNoOfMovies.Name = "lblNoOfMovies";
            this.lblNoOfMovies.Size = new System.Drawing.Size(127, 25);
            this.lblNoOfMovies.TabIndex = 5;
            this.lblNoOfMovies.Text = "No. Of Movies";
            // 
            // txtNoOfMovies
            // 
            this.txtNoOfMovies.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtNoOfMovies.Location = new System.Drawing.Point(308, 189);
            this.txtNoOfMovies.Name = "txtNoOfMovies";
            this.txtNoOfMovies.Size = new System.Drawing.Size(151, 29);
            this.txtNoOfMovies.TabIndex = 6;
            // 
            // txtTotalMovieCount
            // 
            this.txtTotalMovieCount.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtTotalMovieCount.Location = new System.Drawing.Point(694, 432);
            this.txtTotalMovieCount.Name = "txtTotalMovieCount";
            this.txtTotalMovieCount.ReadOnly = true;
            this.txtTotalMovieCount.Size = new System.Drawing.Size(100, 29);
            this.txtTotalMovieCount.TabIndex = 17;
            this.txtTotalMovieCount.TabStop = false;
            // 
            // lblTotalMovieCount
            // 
            this.lblTotalMovieCount.AutoSize = true;
            this.lblTotalMovieCount.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.lblTotalMovieCount.Location = new System.Drawing.Point(518, 432);
            this.lblTotalMovieCount.Name = "lblTotalMovieCount";
            this.lblTotalMovieCount.Size = new System.Drawing.Size(156, 25);
            this.lblTotalMovieCount.TabIndex = 16;
            this.lblTotalMovieCount.Text = "Total Movie Count";
            // 
            // txtTotalLateFee
            // 
            this.txtTotalLateFee.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtTotalLateFee.Location = new System.Drawing.Point(694, 504);
            this.txtTotalLateFee.Name = "txtTotalLateFee";
            this.txtTotalLateFee.ReadOnly = true;
            this.txtTotalLateFee.Size = new System.Drawing.Size(100, 29);
            this.txtTotalLateFee.TabIndex = 19;
            this.txtTotalLateFee.TabStop = false;
            // 
            // lblTotalLateFee
            // 
            this.lblTotalLateFee.AutoSize = true;
            this.lblTotalLateFee.Font = new System.Drawing.Font("Yu Gothic UI", 9F);
            this.lblTotalLateFee.Location = new System.Drawing.Point(518, 504);
            this.lblTotalLateFee.Name = "lblTotalLateFee";
            this.lblTotalLateFee.Size = new System.Drawing.Size(117, 25);
            this.lblTotalLateFee.TabIndex = 18;
            this.lblTotalLateFee.Text = "Total Late Fee";
            // 
            // btnCount
            // 
            this.btnCount.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnCount.ForeColor = System.Drawing.Color.Black;
            this.btnCount.Location = new System.Drawing.Point(523, 189);
            this.btnCount.Name = "btnCount";
            this.btnCount.Size = new System.Drawing.Size(151, 37);
            this.btnCount.TabIndex = 7;
            this.btnCount.Text = "Count Movies";
            this.btnCount.UseVisualStyleBackColor = true;
            this.btnCount.Click += new System.EventHandler(this.btnCount_Click);
            // 
            // frmLibraryMovies
            // 
            this.AcceptButton = this.btnCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(866, 579);
            this.Controls.Add(this.btnCount);
            this.Controls.Add(this.txtTotalMovieCount);
            this.Controls.Add(this.lblTotalMovieCount);
            this.Controls.Add(this.txtTotalLateFee);
            this.Controls.Add(this.lblTotalLateFee);
            this.Controls.Add(this.txtNoOfMovies);
            this.Controls.Add(this.lblNoOfMovies);
            this.Controls.Add(this.txtCustomerType);
            this.Controls.Add(this.lblCustomerType);
            this.Controls.Add(this.lblDateFormat);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtLateFee);
            this.Controls.Add(this.lblLateFee);
            this.Controls.Add(this.txtNumOfDaysLate);
            this.Controls.Add(this.lblNumOfDaysLate);
            this.Controls.Add(this.txtCurrentDate);
            this.Controls.Add(this.lblCurrentDate);
            this.Controls.Add(this.txtDueDate);
            this.Controls.Add(this.lblDueDate);
            this.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmLibraryMovies";
            this.Text = "Library Movies";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDueDate;
        private System.Windows.Forms.TextBox txtDueDate;
        private System.Windows.Forms.Label lblCurrentDate;
        private System.Windows.Forms.TextBox txtCurrentDate;
        private System.Windows.Forms.Label lblNumOfDaysLate;
        private System.Windows.Forms.TextBox txtNumOfDaysLate;
        private System.Windows.Forms.Label lblLateFee;
        private System.Windows.Forms.TextBox txtLateFee;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.Label lblDateFormat;
        private System.Windows.Forms.Label lblCustomerType;
        private System.Windows.Forms.TextBox txtCustomerType;
        private System.Windows.Forms.Label lblNoOfMovies;
        private System.Windows.Forms.TextBox txtNoOfMovies;
        private System.Windows.Forms.TextBox txtTotalMovieCount;
        private System.Windows.Forms.Label lblTotalMovieCount;
        private System.Windows.Forms.TextBox txtTotalLateFee;
        private System.Windows.Forms.Label lblTotalLateFee;
        private System.Windows.Forms.Button btnCount;
    }
}
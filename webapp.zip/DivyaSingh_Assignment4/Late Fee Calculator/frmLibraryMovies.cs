﻿// Created by Divya Singh Thakur
// Student ID : C0838228
// Library Movies Form
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Windows.Forms;

namespace Late_Fee_Calculator
{
    public partial class frmLibraryMovies : Form
    {
        public frmLibraryMovies()
        {
            InitializeComponent();
            //Display the current date
            txtCurrentDate.Text = DateTime.Now.ToString(@"dd-MM-yyyy");
            txtNoOfMovies.TextChanged += txtNoOfMovies_TextChanged;
        }

        public static double LateFeeLib { get; private set; }

        public static class countLibrary
        {
            public static int counterLib;
            public static int movieCount = 0;
            public static double totalLateFeeLib = 0;
        }

        private void OnCalculateButtonPressed(object sender, EventArgs e)
        {

            double numberOfDays = 0;
            double discount = 0;
            int totalMoviesLib = 0;

            // Calculate Late Fee
            CalculateLateFee(numberOfDays, discount, totalMoviesLib);
        }

        private double CalculateLateFee(double numberOfDays, double discount, int totalMoviesLib)

        {

            double lateFee = 0;
            string customerType;

            // Check for Exceptions
            try
            {
                // Validate user entries
                if (IsValidData())
                {

                    // Generate the current date
                    DateTime currentDateTime = DateTime.Now;

                    // Generate the due date based on user entry in txtDueDate textbox
                    DateTime dueDate = DateTime.Parse(txtDueDate.Text);

                    // Calculate the number of days late
                    TimeSpan days = (currentDateTime.Date - dueDate.Date);
                    numberOfDays = days.TotalDays;

                    // Display the number of days late in the textbox txtNum
                    txtNumOfDaysLate.Text = numberOfDays.ToString();

                    // Get discount based on the customer type

                    customerType = txtCustomerType.Text;

                    //Determine customerType and calculate discount
                    switch (customerType)
                    {
                        // New customers get 0% discount
                        case "N":
                            discount = 0;
                            break;
                        // Junior customers get 5% discount
                        case "J":
                            discount = 0.05;
                            break;
                        // Loyal customers get 10% discount
                        case "L":
                            discount = 0.1;
                            break;
                        // If the user does not provide a valid customer type, 0% dicount is given
                        default:
                            discount = 0;
                            break;
                    }

                    // Get number of movies from text box

                    Int32.TryParse(txtNoOfMovies.Text, out totalMoviesLib);

                    // Calculate the late fee 0.57$ per day
                    lateFee = 0.57 * numberOfDays;

                    // Multiply by number of movies to get total late fee
                    lateFee *= totalMoviesLib;


                    // Apply discount to total late fee
                    lateFee -= (lateFee * discount);


                    //Calculate Total number of movies and Total Late Fee
                    countLibrary.counterLib = Convert.ToInt32(txtNoOfMovies.Text);
                    countLibrary.movieCount = countLibrary.movieCount + countLibrary.counterLib;
                    countLibrary.totalLateFeeLib = lateFee + countLibrary.totalLateFeeLib;


                    // Display the late fee as currency
                    txtLateFee.Text = lateFee.ToString("C", new System.Globalization.CultureInfo("en-CA"));

                    // Display Total number of movies and Total Late Fee
                    txtTotalMovieCount.Text = countLibrary.movieCount.ToString();
                    txtTotalLateFee.Text = countLibrary.totalLateFeeLib.ToString("C", new System.Globalization.CultureInfo("en-CA"));

                    //Set the value of static parameter
                    LateFeeLib = countLibrary.totalLateFeeLib;

                    // Place cursor back to Return button
                    btnReturn.Focus();

                }

            }

            // Catch Exceptions
            catch (Exception excp)
            {
                MessageBox.Show(
                excp.Message + "\n\n" +
                excp.GetType().ToString() + "\n" +
                excp.StackTrace, "Exception");
            }
            return lateFee;

        }

        // Validates user's entries
        public bool IsValidData()
        {
            DateTime currentDate = DateTime.Now;
            DateTime dueDate = DateTime.Parse(txtDueDate.Text);
            return
                // Validate Customer Type text box
                IsPresent(txtCustomerType, "Customer Type") &&
                IsCustType(txtCustomerType, "Customer Type") &&


                // Validate if number of movies positive integer
                IsInt32(txtNoOfMovies, "Number of movies") &&

                // Validate Due Date text box
                IsPresent(txtDueDate, "Due Date") &&
                IsDateTime(txtDueDate, "Due Date") &&
                IsPast(currentDate, dueDate, "Due Date");

        }

        // Checks if entry is not entered by the user
        public bool IsPresent(TextBox textBox, string name)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(name + " is a required field.", "Error");
                textBox.Focus();
                return false;
            }
            return true;
        }

        // Checks if the number of movies positive integer
        public bool IsInt32(TextBox textBox, string name)
        {
            int number = 0;
            if (Int32.TryParse(textBox.Text, out number) && number > 0)
            {
                return true;
            }
            else
            {
                MessageBox.Show(name + " must be an integer.", "Error");
                textBox.Focus();
                return false;
            }
        }

        // Checks if the user enters a valid date
        public bool IsDateTime(TextBox textBox, string name)
        {
            DateTime date;
            if (DateTime.TryParse(textBox.Text, out date))
            {
                return true;
            }
            else
            {
                MessageBox.Show(name + " must be a valid date", "Error");
                textBox.Focus();
                return false;
            }
        }

        // Compares two dates and validates if the date is appropriately greater than the other
        public bool IsPast(DateTime currentDate, DateTime dueDate, string name)
        {

            if (currentDate > dueDate)
            {
                return true;
            }

            else
            {
                MessageBox.Show(name + " must be less than Current date", "Error");
                return false;
            }
        }

        // Checks if the user enters a valid customer type
        public bool IsCustType(TextBox textBox, string name)
        {
            string custType = textBox.Text;

            if (custType == "N" || custType == "J" || custType == "L")
            {
                return true;
            }
            else
            {
                MessageBox.Show(name + " must be a valid type", "Error");
                textBox.Focus();
                return false;
            }
        }

        private void OnReturnButtonPressed(object sender, EventArgs e)
        {
            //Clear the text boxes
            txtDueDate.Text = "";
            txtCustomerType.Text = "";
            txtNoOfMovies.Text = "";
            txtNumOfDaysLate.Text = "";
            txtLateFee.Text = "";
            //DialogResult property of the form to OK
            this.DialogResult = DialogResult.OK;
            // Return to main menu
            this.Hide();
        }

        //Clear Late Fee Text box when No. of movies value changes
        private void txtNoOfMovies_TextChanged(object sender, EventArgs e)
        {
            int number;
            bool success = Int32.TryParse(txtNoOfMovies.Text, out number);
            // input is a number
            if (success)
            {
                txtLateFee.Text = " ";
            }
        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            // Opens late films form and returns to the count of movies to number of movies 
            Form lateFilmsForm = new frmLateFilms();
            DialogResult selectedButton = lateFilmsForm.ShowDialog();
            //Code execution is paused while the dialog is open
            if (selectedButton == DialogResult.OK)
                txtNoOfMovies.Text = frmLateFilms.NumCount.ToString();
        }
    }
}

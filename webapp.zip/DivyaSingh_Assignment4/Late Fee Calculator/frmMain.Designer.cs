﻿using System;

namespace Late_Fee_Calculator
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.lblMainMenu = new System.Windows.Forms.Label();
            this.btnNewRelease = new System.Windows.Forms.Button();
            this.btnLibraryMovie = new System.Windows.Forms.Button();
            this.btnKidsMovie = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblTotalLateFeeAll = new System.Windows.Forms.Label();
            this.lblVal = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblMainMenu
            // 
            this.lblMainMenu.AutoSize = true;
            this.lblMainMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblMainMenu.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMainMenu.ForeColor = System.Drawing.Color.Indigo;
            this.lblMainMenu.Location = new System.Drawing.Point(133, 22);
            this.lblMainMenu.Name = "lblMainMenu";
            this.lblMainMenu.Padding = new System.Windows.Forms.Padding(4);
            this.lblMainMenu.Size = new System.Drawing.Size(137, 35);
            this.lblMainMenu.TabIndex = 0;
            this.lblMainMenu.Text = "Main Menu";
            // 
            // btnNewRelease
            // 
            this.btnNewRelease.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewRelease.Location = new System.Drawing.Point(129, 118);
            this.btnNewRelease.Name = "btnNewRelease";
            this.btnNewRelease.Size = new System.Drawing.Size(132, 47);
            this.btnNewRelease.TabIndex = 1;
            this.btnNewRelease.Text = "&New Release";
            this.btnNewRelease.UseVisualStyleBackColor = true;
            this.btnNewRelease.Click += new System.EventHandler(this.OnNewReleaseButtonPressed);
            // 
            // btnLibraryMovie
            // 
            this.btnLibraryMovie.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnLibraryMovie.Location = new System.Drawing.Point(129, 344);
            this.btnLibraryMovie.Name = "btnLibraryMovie";
            this.btnLibraryMovie.Size = new System.Drawing.Size(132, 46);
            this.btnLibraryMovie.TabIndex = 3;
            this.btnLibraryMovie.Text = "&Library Movie";
            this.btnLibraryMovie.UseVisualStyleBackColor = true;
            this.btnLibraryMovie.Click += new System.EventHandler(this.OnLibraryMovieButtonPressed);
            // 
            // btnKidsMovie
            // 
            this.btnKidsMovie.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnKidsMovie.Location = new System.Drawing.Point(129, 231);
            this.btnKidsMovie.Name = "btnKidsMovie";
            this.btnKidsMovie.Size = new System.Drawing.Size(132, 44);
            this.btnKidsMovie.TabIndex = 2;
            this.btnKidsMovie.Text = "&Kids Movie";
            this.btnKidsMovie.UseVisualStyleBackColor = true;
            this.btnKidsMovie.Click += new System.EventHandler(this.OnKidsMovieButtonPressed);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Font = new System.Drawing.Font("Yu Gothic UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnExit.Location = new System.Drawing.Point(129, 450);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(132, 44);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.OnExitButtonPressed);
            // 
            // lblTotalLateFeeAll
            // 
            this.lblTotalLateFeeAll.AutoSize = true;
            this.lblTotalLateFeeAll.BackColor = System.Drawing.Color.Black;
            this.lblTotalLateFeeAll.Font = new System.Drawing.Font("Yu Gothic UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalLateFeeAll.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTotalLateFeeAll.Location = new System.Drawing.Point(320, 247);
            this.lblTotalLateFeeAll.Name = "lblTotalLateFeeAll";
            this.lblTotalLateFeeAll.Size = new System.Drawing.Size(258, 28);
            this.lblTotalLateFeeAll.TabIndex = 5;
            this.lblTotalLateFeeAll.Text = "Total late fee for all movies  :";
            // 
            // lblVal
            // 
            this.lblVal.AutoSize = true;
            this.lblVal.Font = new System.Drawing.Font("Yu Gothic UI", 10F);
            this.lblVal.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblVal.Location = new System.Drawing.Point(575, 247);
            this.lblVal.Name = "lblVal";
            this.lblVal.Size = new System.Drawing.Size(23, 28);
            this.lblVal.TabIndex = 6;
            this.lblVal.Text = "0";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(618, 525);
            this.Controls.Add(this.lblVal);
            this.Controls.Add(this.lblTotalLateFeeAll);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnKidsMovie);
            this.Controls.Add(this.btnLibraryMovie);
            this.Controls.Add(this.btnNewRelease);
            this.Controls.Add(this.lblMainMenu);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.Padding = new System.Windows.Forms.Padding(4);
            this.Text = "Ryan\'s Late Fee Calculator";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void frmMain_Load(object sender, EventArgs e)
        {
       
        }

        #endregion

        private System.Windows.Forms.Label lblMainMenu;
        private System.Windows.Forms.Button btnNewRelease;
        private System.Windows.Forms.Button btnLibraryMovie;
        private System.Windows.Forms.Button btnKidsMovie;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblTotalLateFeeAll;
        private System.Windows.Forms.Label lblVal;
    }
}


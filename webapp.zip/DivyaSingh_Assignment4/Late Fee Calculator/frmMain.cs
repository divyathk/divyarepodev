﻿//Created by:Divya Singh Thakur
//Student Id:c0838228
//Date : 30-Mar-2022
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Late_Fee_Calculator
{
    public partial class frmMain : Form
    {
        private frmNewRelease newReleaseForm;
        private frmLibraryMovies libraryMovieForm;
        private frmKidsMovies kidsMovieForm;

        public frmMain()
        {
            InitializeComponent();
            newReleaseForm = new frmNewRelease();
            libraryMovieForm = new frmLibraryMovies();
            kidsMovieForm = new frmKidsMovies();
        }

        private void OnExitButtonPressed(object sender, EventArgs e)
        {
        // Close the application
            Close();
        }
    
        //Open New Release form from main menu
        private void OnNewReleaseButtonPressed(object sender, EventArgs e)
        {
            // Displays the created instance of the New Releases form
            DialogResult selectedButton = newReleaseForm.ShowDialog();
            // Add calculated late fee and display the result if the user clicks on Ok
            if (selectedButton == DialogResult.OK)
            {               
                CalculateLateFees();
            }
        }
     
        //Open Library Movie form from main menu
        private void OnLibraryMovieButtonPressed(object sender, EventArgs e)
        {
            // Displays the created instance of the Library Movie form
            DialogResult selectedButton = libraryMovieForm.ShowDialog();
            // Add calculated late fee and display the result if the user clicks on Ok
            if (selectedButton == DialogResult.OK)
            {
                CalculateLateFees();
            }

        }
        //Open Kids Movie form from main menu
        private void OnKidsMovieButtonPressed(object sender, EventArgs e)
        {
            // Displays the created instance of the Kids Movie form
            DialogResult selectedButton = kidsMovieForm.ShowDialog();
            // Add calculated late fee and display the result if the user clicks on Ok
            if (selectedButton == DialogResult.OK)
            {
                CalculateLateFees();
            }

        }
        // Calculate the total late fee from each type of movie and display to the main form
        private void CalculateLateFees()
        {
            double totalLateFee = frmNewRelease.LateFeeNew+frmKidsMovies.LateFeeKids+frmLibraryMovies.LateFeeLib;
            //Set the lbl value to total late fee
            lblVal.Text = totalLateFee.ToString("C", new System.Globalization.CultureInfo("en-CA"));
        }
    }
}
